import { useState, useEffect, useCallback } from "react"
import { useNavigate, useLocation } from "react-router-dom"
import {
  LayoutDashboard,
  Network,
  BrainCircuit,
  Ticket,
  ShieldCheck,
  FileBox,
  HeartPulse,
  Coins,
  ScrollText,
  Blocks,
  Puzzle,
  Store,
  Settings as SettingsIcon,
  Activity,
  Shield,
  Sparkles,
  Circle,
  Globe,
  Zap,
  ChevronDown,
  ChevronRight,
  Gauge,
  Send,
  UserCircle,
  BookTemplate,
  UsersRound,
} from "lucide-react"
import { LogoMark } from "@/shared/ui/Logo"
import { UpdateBanner } from "@/shared/ui/UpdateBanner"
import { CommandPalette } from "@/shared/ui/CommandPalette"
import { WelcomeTour } from "@/shared/ui/WelcomeTour"
import { useT, useI18n } from "@/shared/i18n"
import { api } from "@/shared/api/client"

interface LayoutProps {
  children: React.ReactNode
}

/* Layout dimensions (Cowork nav bar) */
const NAV_BAR_WIDTH = 48
const TITLE_BAR_HEIGHT = 30
const STATUS_BAR_HEIGHT = 22

function NavBarDivider() {
  return (
    <div
      className="mx-auto my-[6px]"
      style={{ width: 28, height: 1, background: "rgba(255,255,255,0.12)" }}
    />
  )
}

export function Layout({ children }: LayoutProps) {
  const navigate = useNavigate()
  const location = useLocation()
  const t = useT()
  const { locale } = useI18n()

  const [dispatchCount, setDispatchCount] = useState(0)
  const [autonomyLevel, setAutonomyLevel] = useState("semi-auto")

  const fetchStatusBar = useCallback(async () => {
    try {
      const [dispatches, config] = await Promise.all([
        api.get<{ total: number }>("/dispatch").catch(() => ({ total: 0 })),
        api
          .get<{ config: Record<string, { value: string }> }>("/config")
          .catch(() => null),
      ])
      setDispatchCount(dispatches.total)
      if (config?.config?.AUTONOMY_LEVEL?.value) {
        setAutonomyLevel(config.config.AUTONOMY_LEVEL.value)
      }
    } catch {
      /* status bar data is non-critical */
    }
  }, [])

  useEffect(() => {
    fetchStatusBar()
    const interval = setInterval(fetchStatusBar, 30_000)
    return () => clearInterval(interval)
  }, [fetchStatusBar])

  const autonomyLabels: Record<string, string> = {
    observe: "Observe",
    assist: "Assist",
    "semi-auto": "Semi-Auto",
    autonomous: "Autonomous",
  }

  const cycleAutonomy = async () => {
    const levels = ["observe", "assist", "semi-auto", "autonomous"]
    const idx = levels.indexOf(autonomyLevel)
    const next = levels[(idx + 1) % levels.length]
    setAutonomyLevel(next)
    try {
      await api.put("/config", { key: "AUTONOMY_LEVEL", value: next })
    } catch {
      /* Config save failure is non-fatal */
    }
  }
  const [showManage, setShowManage] = useState(false)
  const [showExtend, setShowExtend] = useState(false)

  function isActive(path: string) {
    return path === "/" ? location.pathname === "/" : location.pathname.startsWith(path)
  }

  /* Core items — always visible (progressive disclosure: primary actions) */
  const coreItems = [
    { icon: LayoutDashboard, path: "/", label: t.nav.dashboard },
    { icon: Ticket, path: "/tickets", label: t.nav.tickets },
    { icon: BrainCircuit, path: "/secretary", label: t.nav.secretary },
    { icon: Sparkles, path: "/brainstorm", label: t.nav.brainstorm },
    { icon: Send, path: "/dispatch", label: (t.nav as Record<string, string>).dispatch ?? "Dispatch" },
    { icon: Activity, path: "/monitor", label: t.nav.monitor },
  ]

  /* Management items — collapsed by default */
  const manageItems = [
    { icon: Network, path: "/org-chart", label: t.nav.orgChart },
    { icon: BookTemplate, path: "/templates", label: t.nav.templates },
    { icon: UsersRound, path: "/crews", label: t.nav.crews },
    { icon: ShieldCheck, path: "/approvals", label: t.nav.approvals },
    { icon: FileBox, path: "/artifacts", label: t.nav.artifacts },
    { icon: HeartPulse, path: "/heartbeats", label: t.nav.heartbeats },
    { icon: Coins, path: "/costs", label: t.nav.costs },
    { icon: ScrollText, path: "/audit", label: t.nav.audit },
  ]

  /* Extension items — collapsed by default */
  const extendItems = [
    { icon: Blocks, path: "/skills", label: t.nav.skills },
    { icon: Puzzle, path: "/plugins", label: t.nav.plugins },
    { icon: Blocks, path: "/extensions", label: t.nav.extensions },
    { icon: Store, path: "/marketplace", label: t.nav.marketplace },
  ]

  /* Auto-expand sections when an item in them is active */
  const manageActive = manageItems.some((item) => isActive(item.path))
  const extendActive = extendItems.some((item) => isActive(item.path))
  const isManageOpen = showManage || manageActive
  const isExtendOpen = showExtend || extendActive

  const bottomItems = [
    { icon: UserCircle, path: "/operator-profile", label: "Operator Profile" },
    { icon: Shield, path: "/permissions", label: t.nav.permissions },
    { icon: SettingsIcon, path: "/settings", label: t.nav.settings },
  ]

  const pageTitles: Record<string, string> = {
    "/": t.nav.dashboard,
    "/org-chart": t.nav.orgChart,
    "/secretary": t.nav.secretary,
    "/tickets": t.nav.tickets,
    "/approvals": t.nav.approvals,
    "/artifacts": t.nav.artifacts,
    "/heartbeats": t.nav.heartbeats,
    "/costs": t.nav.costManagement,
    "/audit": t.nav.audit,
    "/skills": t.nav.skills,
    "/skills/create": t.nav.skillCreate,
    "/plugins": t.nav.plugins,
    "/extensions": t.nav.extensions,
    "/marketplace": t.nav.marketplace,
    "/templates": t.nav.templates,
    "/crews": t.nav.crews,
    "/brainstorm": t.nav.brainstorm,
    "/monitor": t.nav.monitor,
    "/permissions": t.nav.permissions,
    "/settings": t.nav.settings,
    "/dispatch": (t.nav as Record<string, string>).dispatch ?? "Dispatch",
    "/operator-profile": "Operator Profile",
  }

  const currentTitle =
    pageTitles[location.pathname] ??
    (location.pathname.startsWith("/tickets/") ? t.nav.ticketDetail : "")

  /* Nav button: 48x48px icon area, 24px icon, 2px left border accent */
  function renderNavButton(item: { icon: React.ElementType; path: string; label: string }) {
    const active = isActive(item.path)
    return (
      <button
        key={item.path}
        onClick={() => navigate(item.path)}
        className="group relative flex items-center justify-center"
        style={{
          width: NAV_BAR_WIDTH,
          height: NAV_BAR_WIDTH,
          color: active ? "var(--text-primary)" : "var(--text-muted)",
          borderLeft: active ? "2px solid var(--accent)" : "2px solid transparent",
          background: active ? "rgba(255,255,255,0.07)" : "transparent",
        }}
        onMouseEnter={(e) => {
          if (!active) {
            e.currentTarget.style.background = "var(--bg-hover)"
            e.currentTarget.style.color = "var(--text-primary)"
          }
        }}
        onMouseLeave={(e) => {
          if (!active) {
            e.currentTarget.style.background = "transparent"
            e.currentTarget.style.color = "var(--text-muted)"
          }
        }}
        aria-label={item.label}
        aria-current={active ? "page" : undefined}
      >
        <item.icon size={24} strokeWidth={active ? 2 : 1.5} />
        {/* Tooltip */}
        <span
          role="tooltip"
          className="pointer-events-none absolute left-[52px] px-2 py-1 rounded text-[11px] text-[var(--text-primary)] bg-[var(--bg-overlay)] border border-[var(--border)] whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity z-50"
          style={{ boxShadow: "var(--shadow-popup)" }}
        >
          {item.label}
        </span>
      </button>
    )
  }

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-[var(--bg-base)]">
      {/* Title Bar — 30px */}
      <header
        className="flex items-center shrink-0 select-none border-b border-[var(--border)]"
        style={{ height: TITLE_BAR_HEIGHT, background: "var(--bg-titlebar)" }}
      >
        <div className="flex items-center gap-2 px-3" style={{ width: NAV_BAR_WIDTH }}>
          <LogoMark size={14} />
        </div>
        <div className="flex-1 text-center">
          <span className="text-[11px] font-medium text-[var(--text-secondary)] tracking-wide">
            {currentTitle}
          </span>
        </div>
        <div className="w-[60px]" />
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Nav Bar — 48px, Cowork style */}
        <nav
          className="shrink-0 flex flex-col items-center border-r border-[var(--border)]"
          style={{ width: NAV_BAR_WIDTH, background: "var(--bg-nav-bar)" }}
          aria-label={t.nav.navigation}
        >
          <div className="flex flex-col items-center pt-[4px]">
            {/* Core — always visible */}
            {coreItems.map((item) => renderNavButton(item))}

            {/* Manage section — collapsible */}
            <NavBarDivider />
            <button
              onClick={() => setShowManage((v) => !v)}
              className="flex items-center justify-center"
              style={{
                width: NAV_BAR_WIDTH,
                height: 20,
                color: "var(--text-muted)",
                opacity: 0.6,
              }}
              aria-label="Manage"
            >
              {isManageOpen ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
            </button>
            {isManageOpen && manageItems.map((item) => renderNavButton(item))}

            {/* Extend section — collapsible */}
            <NavBarDivider />
            <button
              onClick={() => setShowExtend((v) => !v)}
              className="flex items-center justify-center"
              style={{
                width: NAV_BAR_WIDTH,
                height: 20,
                color: "var(--text-muted)",
                opacity: 0.6,
              }}
              aria-label="Extend"
            >
              {isExtendOpen ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
            </button>
            {isExtendOpen && extendItems.map((item) => renderNavButton(item))}
          </div>
          <div className="flex-1" />
          <div className="flex flex-col items-center pb-[4px]">
            <NavBarDivider />
            {bottomItems.map((item) => renderNavButton(item))}
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 overflow-auto bg-[var(--bg-base)]">
          {children}
        </main>
      </div>

      {/* Status Bar — 22px, Cowork-inspired (autonomy dial + dispatch feed) */}
      <footer
        className="flex items-center shrink-0 text-[12px]"
        style={{ height: STATUS_BAR_HEIGHT, lineHeight: `${STATUS_BAR_HEIGHT}px`, background: "var(--bg-statusbar)" }}
      >
        <div className="flex items-center h-full text-[var(--statusbar-fg)]">
          <div className="flex items-center gap-1 px-2 h-full hover:bg-[rgba(255,255,255,0.12)]">
            <Circle size={7} fill="var(--statusbar-fg)" stroke="none" style={{ opacity: 0.8 }} />
            <span>{t.common.connected ?? "OK"}</span>
          </div>
          {/* Dispatch count — Cowork activity feed pattern */}
          <button
            onClick={() => navigate("/monitor")}
            className="flex items-center gap-1 px-2 h-full hover:bg-[rgba(255,255,255,0.12)]"
          >
            <Send size={10} />
            <span>{dispatchCount} {t.common.jobs ?? "Tasks"}</span>
          </button>
        </div>
        <div className="flex-1" />
        <div className="flex items-center h-full text-[var(--statusbar-fg)]">
          {/* Autonomy Dial — Cowork/Smashing Magazine agentic UX pattern */}
          <button
            onClick={cycleAutonomy}
            className="flex items-center gap-1 px-2 h-full hover:bg-[rgba(255,255,255,0.12)]"
            title="Click to change autonomy level"
          >
            <Gauge size={11} />
            <span>{autonomyLabels[autonomyLevel]}</span>
          </button>
          <button
            onClick={() => navigate("/settings")}
            className="flex items-center gap-1 px-2 h-full hover:bg-[rgba(255,255,255,0.12)]"
          >
            <Globe size={11} />
            <span>{locale.toUpperCase()}</span>
          </button>
          <div className="flex items-center gap-1 px-2 h-full hover:bg-[rgba(255,255,255,0.12)]">
            <Zap size={11} />
            <span>Quality</span>
          </div>
        </div>
      </footer>

      <CommandPalette />
      <UpdateBanner />
      <WelcomeTour />
    </div>
  )
}
