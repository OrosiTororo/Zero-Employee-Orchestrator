import { useState, useEffect, useCallback } from "react"
import { useNavigate } from "react-router-dom"
import { Coins, TrendingUp, ShieldAlert, Receipt, ArrowRight } from "lucide-react"
import { useT } from "@/shared/i18n"
import { api } from "@/shared/api/client"

interface BudgetPolicy {
  id: string
  name: string
  scope_type: string
  period_type: string
  limit_usd: number
}

interface CostSummary {
  today: number
  this_week: number
  this_month: number
  total: number
}

export function CostsPage() {
  const t = useT()
  const navigate = useNavigate()
  const companyId = localStorage.getItem("company_id") || ""
  const [, setBudgets] = useState<BudgetPolicy[]>([])
  const [summary, setSummary] = useState<CostSummary>({ today: 0, this_week: 0, this_month: 0, total: 0 })
  const [, setLoading] = useState(true)

  const fetchData = useCallback(async () => {
    if (!companyId) { setLoading(false); return }
    setLoading(true)
    try {
      const [b, s] = await Promise.all([
        api.get<BudgetPolicy[]>(`/companies/${companyId}/budgets`).catch((e) => { console.warn("Budgets:", e); return [] }),
        api.get<CostSummary>(`/companies/${companyId}/cost-summary`).catch((e) => { console.warn("Cost summary:", e); return { today: 0, this_week: 0, this_month: 0, total: 0 } }),
      ])
      setBudgets(b)
      setSummary(s)
    } finally {
      setLoading(false)
    }
  }, [companyId])

  useEffect(() => { fetchData() }, [fetchData])

  return (
    <div className="h-full overflow-auto">
      <div className="max-w-[900px] mx-auto px-6 py-6">
        <div className="flex items-center gap-2 mb-6">
          <Coins size={18} className="text-[var(--warning)]" />
          <h2 className="text-[14px] font-medium text-[var(--text-primary)]">{t.costs.title}</h2>
        </div>

        {/* Budget Policies */}
        <section className="mb-6 rounded border border-[var(--border)] bg-[var(--bg-surface)]">
          <div className="flex items-center gap-2 px-4 py-2 border-b border-[var(--border)]">
            <ShieldAlert size={14} className="text-[var(--warning)]" />
            <span className="text-[12px] font-medium text-[var(--text-primary)]">{t.costs.budgetPolicies}</span>
          </div>
          <div className="px-4 py-4">
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="rounded p-3 border border-[var(--border)] bg-[var(--bg-base)]">
                <div className="text-[11px] text-[var(--text-muted)] mb-1">{t.costs.dailyLimit}</div>
                <div className="text-[16px] font-semibold text-[var(--text-primary)]">{t.costs.notSet}</div>
              </div>
              <div className="rounded p-3 border border-[var(--border)] bg-[var(--bg-base)]">
                <div className="text-[11px] text-[var(--text-muted)] mb-1">{t.costs.weeklyLimit}</div>
                <div className="text-[16px] font-semibold text-[var(--text-primary)]">{t.costs.notSet}</div>
              </div>
              <div className="rounded p-3 border border-[var(--border)] bg-[var(--bg-base)]">
                <div className="text-[11px] text-[var(--text-muted)] mb-1">{t.costs.monthlyLimit}</div>
                <div className="text-[16px] font-semibold text-[var(--text-primary)]">{t.costs.notSet}</div>
              </div>
            </div>
            <div className="text-[12px] text-[var(--text-muted)]">{t.costs.budgetDesc}</div>
          </div>
        </section>

        {/* Spending Breakdown */}
        <section className="mb-6 rounded border border-[var(--border)] bg-[var(--bg-surface)]">
          <div className="flex items-center gap-2 px-4 py-2 border-b border-[var(--border)]">
            <TrendingUp size={14} className="text-[var(--accent)]" />
            <span className="text-[12px] font-medium text-[var(--text-primary)]">{t.costs.spending}</span>
          </div>
          <div className="px-4 py-4">
            <div className="grid grid-cols-4 gap-4 mb-4">
              {[
                { label: t.costs.today, value: `$${summary.today.toFixed(2)}` },
                { label: t.costs.thisWeek, value: `$${summary.this_week.toFixed(2)}` },
                { label: t.costs.thisMonth, value: `$${summary.this_month.toFixed(2)}` },
                { label: t.costs.total, value: `$${summary.total.toFixed(2)}` },
              ].map((item, i) => (
                <div key={i}>
                  <div className="text-[11px] text-[var(--text-muted)]">{item.label}</div>
                  <div className="text-[18px] font-semibold text-[var(--text-primary)]">{item.value}</div>
                </div>
              ))}
            </div>
            <div className="text-center text-[12px] text-[var(--text-muted)] py-4 border-t border-[var(--border)]">
              {t.costs.breakdownHint}
            </div>
          </div>
        </section>

        {/* Cost Ledger */}
        <section className="rounded border border-[var(--border)] bg-[var(--bg-surface)] overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-2 border-b border-[var(--border)]">
            <Receipt size={14} className="text-[var(--accent)]" />
            <span className="text-[12px] font-medium text-[var(--text-primary)]">{t.costs.ledger}</span>
          </div>
          <div className="px-4">
            <div className="grid grid-cols-5 gap-2 py-2 text-[11px] text-[var(--text-muted)] border-b border-[var(--border)] font-medium">
              <span>{t.costs.dateTime}</span>
              <span>{t.costs.ticket}</span>
              <span>{t.costs.model}</span>
              <span>{t.costs.tokens}</span>
              <span className="text-right">{t.costs.cost}</span>
            </div>
            <div className="py-6 text-center text-[var(--text-muted)]">
              <Coins size={32} className="mx-auto mb-3 opacity-30" />
              <p className="text-[12px] mb-2">{t.costs.emptyState}</p>
              <button onClick={() => navigate("/")} className="inline-flex items-center gap-1 text-[12px] text-[var(--accent)] hover:underline">
                {t.dashboard?.requestTask ?? "Request a task"} <ArrowRight size={12} />
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
